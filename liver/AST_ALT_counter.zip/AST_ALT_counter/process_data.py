# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 09:09:01 2022

@author: Steven
"""

import pandas as pd
import numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-f', '--filename',    help='input filename', default="input.csv")
args = parser.parse_args()

#### Lookup dataframes

# Look ups go here. Needs to be updated
AST_lookup = pd.DataFrame( {'age_group': ['<3wks', '3wks-5y', '6-10y', '11-16y', 
                                      '17-30y', '31-50y', '51-70y', '>70y'],
                        'upper_limit': np.arange(8)*100  }  )

ALT_lookup = pd.DataFrame( {'age_group': ['<3wks', '3wks-5y', '6-10y', '11-16y', 
                                      '17-30y', '31-50y', '51-70y', '>70y'],
                        'upper_limit': np.arange(8)*100  }  )

#### Functions

def process_data(input_filepath, output_filepath):    
    '''

    Parameters
    ----------
    input_filepath : Path of csv file input. This csv should have the following column headings:
                     patient_id, DOB, sample_date, AST, ALT

    output_filepath : Path of csv file output

    Returns
    -------
    df_out : dataframe with counts of unique patients by measurement, month and age group

    '''
    
    # Read in data
    df = pd.read_csv(input_filepath, 
                     parse_dates=['DOB', 'sample_date'], 
                     dayfirst = True)  
  
    # Add age in years
    df['age'] = (df.sample_date - df.DOB).dt.days / 365.25
    
    # Add age group       
    df['age_group'] = pd.cut( df['age'], 
                              bins = [0, 21/365.25, 5, 10, 16, 30, 50, 70, 120],
                              labels = ['<3wks', '3wks-5y', '6-10y', '11-16y', 
                                '17-30y', '31-50y', '51-70y', '>70y'])
    
    # Add month
    df['month'] = df['sample_date'].dt.strftime('%b-%Y')
    
    # Create dataframe that will be filled out and be the final output
    cols = ['count', 'age_group'] + pd.date_range('2018-01-01','2022-03-01', 
              freq='MS').strftime("%b %Y").tolist()
    
    df_out = pd.DataFrame(columns=cols)
     
    # Merge 
    df_sub = sub_process(df, 'AST', False)    
    df_out = df_out.merge(df_sub, how = 'outer')
    
    df_sub = sub_process(df, 'AST', True)    
    df_out = df_out.merge(df_sub, how = 'outer')
    
    df_sub = sub_process(df, 'ALT', False)    
    df_out = df_out.merge(df_sub, how = 'outer')
    
    df_sub = sub_process(df, 'ALT', True)    
    df_out = df_out.merge(df_sub, how = 'outer')
    
    # All nan are zero counts
    df_out = df_out.replace(np.nan, 0)
  
    # Sort columns
    df_out = df_out.reindex(columns=cols)
    
    # Save out
    df_out.to_csv(output_filepath, index=False)  
    
    return 

    
def sub_process(df, measure, elevated):
    '''

    Parameters
    ----------
    df : Semi-processed dataframe
    measure : 'AST' or 'ALT'
    elevated : True or False. If True, counts unique patients who value for 
               measure was at least 2x the upper limit

    Returns
    -------
    df : dataframe with counts for the chosen measure, by month and age group

    '''
    
    # Find number of unique patients with an AST measurement.
    # Drop any that have nan
    df = df.dropna(subset = [measure])
    
    if elevated == True:       
        col_name = measure + '_2x_normal'
        
        if measure == 'AST':
            lookup = AST_lookup
            
        elif measure == 'ALT':
            lookup = ALT_lookup
        
        df = df.merge(lookup, how = 'left')
        
        df = df[ df[measure] > 2* df['upper_limit']]
        
    else:        
        col_name = measure + '_all_tests'
    
    # Count unique patient ids, grouped by age_group and month
    df = df.groupby(['age_group', 'month'])['patient_id'].nunique()
    
    # Turn multi-index series into a dataframe
    df = df.unstack(level=1)
    
    # Get rid of redundant column multi-index
    df.columns = df.columns.get_level_values('month')
    
    # Insert age group and name of variable being counted
    # Merge with lookup so all age groups are present
    # Rest index
    df.insert(0, 'age_group', df.index)
    df.index = np.arange(len(df))
    df = df.merge(AST_lookup['age_group'], how = 'outer')   
    df.insert(0, 'count', col_name)
   
    return df
    
####  
 
process_data(args.filename, 'summary_table.csv')

    

