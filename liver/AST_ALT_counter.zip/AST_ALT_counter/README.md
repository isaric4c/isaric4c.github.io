# AST_ALT_counter

This code takes data consisting of AST and ALT measurements for individuals, and produces a dataset consisting of monthly counts of total and elevated AST and ALT levels. The file test.csv indicates the format the input data should be in.
